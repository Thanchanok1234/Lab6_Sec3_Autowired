package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.model.Customer;
import com.example.services.CustomerService;

@RestController
@RequestMapping("/setter")
public class SetterInjectionCustomerController {
						// Constructor injection
    private CustomerService customerService;
    @Autowired
    public void setterInjectionCustomerService(CustomerService customerService) {
    	this.customerService=customerService;
    }

    @GetMapping("/{id}") // Get http://localhost:8080/setter/15
    public String getCustomerById(@PathVariable("id") Long id) {
        Customer cust= customerService.getCustomerById(id);
        return "Setter Injection : Id : "+cust.getId()+ ", Name : "+ cust.getName();
    }
    
    @GetMapping("/search") // http://localhost:8080/setter/search?id=15
    public String SearchCustomerById(@RequestParam("id") Long id) {
        Customer cust= customerService.getCustomerById(id);
        return "Setter Injection : Id : "+cust.getId()+ ", Name : "+ cust.getName();
    }
    
    @GetMapping("/byidname") //http://localhost:8080/setter/byidname?id=15&name=jeno

    public String SearchCustomerByIdName(@RequestParam("id") Long id, @RequestParam("name") String name) {
        Customer cust= customerService.getCustomerByIdName(id,name);
        return "Setter Injection : Id : "+cust.getId()+ ", Name : "+ cust.getName();
    }
    
    @GetMapping("/customer/{id}/{name}") // Get http://localhost:8080/setter/customer/15/jeno
    public String getCustomerByIdName(@PathVariable("id") Long id, @PathVariable("name") String name) {
        Customer cust= customerService.getCustomerByIdName(id,name);
        return "Setter Injection : Id : "+cust.getId()+ ", Name : "+ cust.getName();
    }
    
    @GetMapping("/customerlist") // http://localhost:8080/setter/customerlist
    public List<Customer> getCustomerlist() {
        return customerService.getCustomerList();
    }
    
}